/root/coding/MeinOS/hypervisor/cosmos_lkm.o
/root/coding/MeinOS/hypervisor/build/cosmos_hypervisor_all.o
